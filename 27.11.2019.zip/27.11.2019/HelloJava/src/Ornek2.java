import java.util.Scanner;

public class Ornek2 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("L�tfen ad�n�z� giriniz...");
		String ad = sc.next();
		
		System.out.println("L�tfen soyad�n�z� giriniz...");
		String soyad = sc.next();
		
		System.out.println(ad +" "+ soyad);
	}
}
